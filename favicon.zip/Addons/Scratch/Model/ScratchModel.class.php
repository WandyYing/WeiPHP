<?php

namespace Addons\Scratch\Model;
use Think\Model;

/**
 * Scratch模型
 */
class ScratchModel extends Model{

}
