<?php

namespace Addons\HelloWorld\Controller;
use Home\Controller\AddonsController;

class HelloWorldController extends AddonsController{

}
