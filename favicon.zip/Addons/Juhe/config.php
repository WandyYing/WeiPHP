<?php
return array (
		'stock' => array ( // 配置在表单中的键名 ,这个会是config[random]
				'title' => '股票数据的AppKey:', // 表单的文字
				'type' => 'text', // 表单的类型：text、textarea、checkbox、radio、select等
				'value' => ''  // 表单的默认值
				),
		'exchange' => array ( // 配置在表单中的键名 ,这个会是config[random]
				'title' => '货币汇率的AppKey:', // 表单的文字
				'type' => 'text', // 表单的类型：text、textarea、checkbox、radio、select等
				'value' => ''  // 表单的默认值
				),
		'gold' => array ( // 配置在表单中的键名 ,这个会是config[random]
				'title' => '黄金数据的AppKey:', // 表单的文字
				'type' => 'text', // 表单的类型：text、textarea、checkbox、radio、select等
				'value' => ''  // 表单的默认值
				) 
);
					