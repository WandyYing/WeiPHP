<?php

define("PARTNER", "2088002145015848");
define("KEY", "u0pet4lwrp1yqryjotop8vwlwqp2o7dy");
define("SELLER_EMAIL", "kk4021@163.com");
define("NOTIFY_URL", "");
define("RETURN_URL", "");
$notify_url=NOTIFY_URL;
$return_url=RETURN_URL;
$partner=PARTNER;
$key=KEY;
$seller_email=SELLER_EMAIL;
/* echo $seller_email;
echo "<br/>";
echo $key;
echo "<br/>";
echo $notify_url;
echo "<br/>";
echo $return_url;
echo "<br/>";
echo $partner; */
?>