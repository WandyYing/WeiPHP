<?php

namespace Addons\Survey\Model;
use Think\Model;

/**
 * Survey模型
 */
class SurveyModel extends Model{

}
