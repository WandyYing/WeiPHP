<?php
return array (
		'title' => array (
				'title' => '宣传页标题名:',
				'type' => 'text',
				'value' => 'WeiPHP官方微信公众号',
				'tip' => '可以为空'
		),		
		'img' => array (
				'title' => '二维码图片:',
				'type' => 'picture',
				'value' => '',
				'tip' => '到公众平台下载边长为12CM的二维码图片再上传' 
		),

		'info' => array (
				'title' => '功能简介:',
				'type' => 'textarea',
				'value' => '微信营销管理平台为个人和企业提供基于微信公众平台的一系列功能，包括智能回复、微信3G网站、互动营销活动，会员管理，在线订单，数据统计等系统功能,带给你全新的微信互动营销体验。',
				'tip' => '简述关注后的好处，150文字内最佳' 
		),
		'copyright' => array (
				'title' => '版权信息:',
				'type' => 'text',
				'value' => '©2001-2013 WeiPHP官方微信公众号版权所有',
				'tip' => '' 
		) 
);
					